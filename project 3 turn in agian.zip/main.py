import client_magic
import assisant_magic
import cpa_magic
import tax_return_magic
from connection import get_connection
import database
# import all files to get the functions to work
MAIN_MENU = '''\n Please select an option: 
1. Assistant Info
2. Cpa Info
3. Client info
4. Tax return info
5. Exit
If starting from scratch. Enter Assistant, Cpa, Client, Tax return\nIn that order unless You know the corresponding Ids.
Your Selection: 
'''


def main_menu():
    connection = get_connection()
    database.create_tables(connection)
    while (user_input := input(MAIN_MENU)) != '5':
        if user_input == '1':
            assisant_magic.asi_menu_options()
        elif user_input == '2':
            cpa_magic.cpa_menu_options()
        elif user_input == '3':
            client_magic.client_menu_options()
        elif user_input == '4':
            tax_return_magic.tax_return_menu_options()


if __name__ == "__main__":
    main_menu()
