from modle.tax_return import Tax_return
from modle.cpa import Cpa


def _print_client(tax):  # print for checkers
    print(tax)


def compare():
    new = input("Cpa Id to check for assistant filed it: ")  # used to fetch in cpa info
    yo = Cpa.get_cpa_single_info2(new)  # get list from cpa since assistant filed if they did in cpa 'file'
    yoo = yo[3]  # splitting the list
    if yoo == 'yes':  # if assistant filed make check no
        yoo = 'no'
    elif yoo == 'no':  # if assistant didn't file make check yes
        yoo = 'yes'
    else:
        yoo = 'no'
    return yoo


def create_tax_return():
    tax_id = input("Enter tax_id : ")
    Status = input("Enter Filling Status Marker (yes/no): ")  # time depends on this, separate from markers
    if Status == 'yes':  # status is a yes or no. if yes get time, if no time is none
        time = input("Enter Time of Filling(mm/dd/yyy): ")  # give time
    else:
        time = 'Not filed'  # if status is not 'filed', get no time
    client_id = input("Enter Client Id: ")
    cpa_check = compare()  # checking assistant filed it to make cpa check yes or no
    #   cpa_check = input("Enter if cpa_check: ")
    bert = Tax_return(tax_id, Status, time, client_id, cpa_check)  # insert into tax table class
    Tax_return.save(bert)  # save to tax class to enter into database


def list_all_tax_return():
    clients = Tax_return.get_tax_return_info()  # get data from tax
    if clients is not None:  # error handle, if none go to else
        for client in clients:
            _print_client(client)  # print out the data unpacked from tax return magic
    else:
        return "No clients available"


def prompt_add_info():  # let's change the marker
    cpa_check = input("New Status: ")
    tax_id = input("What is the Tax ID to change Marker Status: ")
    try:
        return cpa_check, tax_id  # return new marker and the id need to change
    except:
        print("Try again")  # do it again
    return "Failed"


def update_tax():
    yo, no = prompt_add_info()
    Tax_return.update(no, yo)


def single_tax():
    old = input("What is the Tax Id: ")
    bert = Tax_return.get_tax_return_single_info(old)
    if bert is not None:
        return _print_client(bert)  # grabbing print function
    else:
        return "No clients available"  # error handling


# initializing menu for tax
tax_menu = '''\nPlease select one of the following options:
1. Add Tax Return Information.
2. Check Tax Return Information.
3. Check Single Cpa Check (Checker).
4. Update Cpa Check (Marker).
5. Return to Main Menu
Your selection: '''


def tax_return_menu_options():
    while (options := input(tax_menu)) != '5':
        if options == '1':
            create_tax_return()  # lets create a tax
        elif options == '2':
            list_all_tax_return()  # let's use check if the data is their
        elif options == '3':  # let's use check if the single data set is their
            single_tax()
        elif options == '4':
            update_tax()  # update the marker manually for user if other markers change
        else:
            print('no')
