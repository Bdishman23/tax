from modle.assistant import Assistant


def create_assistant():
    assistant_id = input("Enter Assistant_id : ")
    assistant_name = input("Enter Assistant Name: ")
    poll = Assistant(assistant_id, assistant_name)
    poll.save()


def list_all_assistant():
    clients = Assistant.get_assistant_info()
    if clients is not None:
        for client in clients:
            _print_assistant(client)
    else:
        return "No clients available"


def _print_assistant(assistant):
    print(assistant)  # print the data guys


def list_single_assistant():
    old_id = input("What Assistant ID Are you looking for?: ")
    clients = Assistant.get_assistant_single_info(old_id)
    if clients is not None:
        return _print_assistant(clients)
    else:
        return "No clients available"


def prompt_add_info():
    name = input("What is the New Name: ")
    a_id = input("Returning Assistant ID: ")
    try:
        return name, a_id
    except:
        print("Try again")
    return "Failed"


def update_assistant():
    yo, no = prompt_add_info()
    Assistant.update(no, yo)


# initialize menu
asi_menu = '''\nPlease select one of the following options:
1. Add Assistant Information.
2. View all Assistant.
3. View Single Assistant.
4. Update Assistant Name.
5. Return Back to Main menu.
Your selection: '''


def asi_menu_options():
    while (options := input(asi_menu)) != '5':
        if options == '1':
            create_assistant()
        elif options == '2':
            list_all_assistant()
        elif options == '3':
            list_single_assistant()
        elif options == '4':
            update_assistant()
        else:
            print("Return to main menu")
