from modle.client import Client


def _print_client(client):
    print(client)  # print dta from client


def create_client():  # let's add the data to the client table yoooo
    client_id = input("Enter client_id : ")
    client_name = input("Enter Company Name: ")
    client_address = input("Enter Address: ")
    client_income = input("Enter income: ")
    client_tax_materials = input("Enter Tax materials: ")
    client_cpa_id = input("Enter Cpa Id: ")
    bert = Client(client_id, client_name, client_address, client_income, client_tax_materials, client_cpa_id)
    Client.save(bert)  # lets save it boyyyyyyy


def prompt_add_info():
    filed = input("New Tax Material Status: ")  # new marker status
    cpa_id = input(" Client ID: ")  # where to place the new marker
    try:
        return filed, cpa_id
    except:
        print("Try again")  # try again
    return "Failed"  # ultimate fail error


def update_client():
    yo, no = prompt_add_info()
    Client.update(no, yo)  # let's update that marker


def single_client():  # single data grab checker
    old_id = input("What Client id Are you looking for?: ")
    clients = Client.get_client_single_info(old_id)
    if clients is not None:
        return _print_client(clients)  # let's print the data boyyyy
    else:
        return "No clients available"  # error handle if the id ant right


def list_all_client():  # all data checker
    clients = Client.get_client_info()  # get all data from client data
    if clients is not None:
        for client in clients:
            _print_client(client)  # print boyyy
    else:
        return "No clients available"


client_menu = '''\nPlease select one of the following options:
1. Add Client Information.
2. View Client Information.
3. Check Tax Material Marker Specific.
4. Update Tax materials (Marker).
5. Return to Main Menu
Dont forget to update Cpa or Tax Return Status Markers.
Your selection: '''


def client_menu_options():
    while (options := input(client_menu)) != '5':
        if options == '1':
            create_client()
        elif options == '2':
            list_all_client()
        elif options == '3':
            single_client()
        elif options == '4':
            update_client()
        else:
            print('Returning back to main menu.')
