CREATE_ASSISTANT = """CREATE TABLE IF NOT EXISTS assistant(a_id SERIAL PRIMARY KEY, name TEXT);"""
# Create Assistant with columns of id, and Full Name
CREATE_CPA = """CREATE TABLE IF NOT EXISTS cpa (cpa_id SERIAL PRIMARY KEY, 
    Company_title TEXT, filed TEXT, a_id SERIAL, FOREIGN KEY (a_id) REFERENCES assistant(a_id));"""
# Create Cpa with columns of id, Company Name, filed, Assistant id
CREATE_CLIENT = """CREATE TABLE IF NOT EXISTS client
(client_id SERIAL PRIMARY KEY, name TEXT, address TEXT, income SERIAL, tax_materials TEXT, cpa_id SERIAL, 
FOREIGN KEY (cpa_id) REFERENCES cpa(cpa_id));"""
# Create Client with columns id, name, address. income, tax materials, cpa id
CREATE_TAX_RETURN = """CREATE TABLE IF NOT EXISTS tax_return 
(tax_id SERIAL PRIMARY KEY, Status TEXT, time TEXT, cpa_check TEXT, client_id SERIAL, 
FOREIGN KEY (client_id) REFERENCES client(client_id));"""
# Create Tex return with columns of id, status, time, cpa check, client id
# status is if it was file, cpa check depends on the assistant checking in cpa table(filed),
# time depends on this status in tax


# SELECT STATEMENTS

SELECT_CLIENT = "SELECT * FROM client WHERE client_id = %s;"  # select all data with client id matching
SELECT_ASSISTANT = "SELECT * FROM assistant WHERE a_id = %s;"  # select all data with assistant id matching
SELECT_SINGLE_CPAA = "SELECT * FROM cpa WHERE cpa_id = %s;"  # select all data with cpa id matching
SELECT_TAX = "SELECT * FROM tax_return WHERE tax_id = %s;"  # select all data with tax id matching
SELECT_ALL_CLIENT = """SELECT * FROM client;"""  # select all data
SELECT_ALL_CPA = """SELECT * FROM cpa;"""  # select all data
SELECT_ALL_ASSISTANT = """SELECT * FROM assistant"""  # select all data
SELECT_ALL_TAX_RETURNS = """SELECT * FROM tax_return;"""  # select all data

# INSERT STATEMENTS, data values being entered into the database
INSERT_CPA = "INSERT INTO cpa (cpa_id, Company_title, filed, a_id) VALUES (%s, %s, %s, %s);"
INSERT_CLIENT = ("INSERT INTO client (client_id, name, address, income, tax_materials, cpa_id)"
                 " VALUES (%s, %s, %s, %s, %s, %s);")
INSERT_TAX_RETURN = "INSERT INTO tax_return (tax_id, Status, time,  client_id, cpa_check) VALUES (%s, %s,%s ,%s, %s);"
INSERT_ASSISTANT = "INSERT INTO assistant (a_id, name) VALUES (%s, %s );"

# Checking if Id's exist
CHECK_IF_ASSISTANT_EXIST = """SELECT * FROM assistant WHERE a_id = %s;"""
CHECK_IF_ITEM_NAME_EXISTS = """SELECT * FROM cpa WHERE cpa_id = %s;"""
CHECK_IF_CLIENT_EXIST = """SELECT * FROM client WHERE client_id = %s;"""
CHECK_IF_TAX_EXISTS = """SELECT * FROM tax_return WHERE tax_id = %s;"""

# updating data in the database, all updating my markers(status, filed, cpa check)
UPDATE_CLIENT = "UPDATE client SET tax_materials = %s WHERE client_id = %s;"
UPDATE_CPA = "UPDATE cpa SET filed = %s WHERE cpa_id = %s;"
UPDATE_ASSISTANT = "UPDATE assistant SET name = %s WHERE a_id = %s;"  # updating the name for giggles
UPDATE_TAX = "UPDATE tax_return SET cpa_check = %s WHERE tax_id = %s;"


def create_tables(connection):  # Creating tables, initializing
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(CREATE_CPA)
            cursor.execute(CREATE_ASSISTANT)
            cursor.execute(CREATE_CLIENT)
            cursor.execute(CREATE_TAX_RETURN)


# Create clint data with insert
def create_client(connection, client_id, name, address, income, tax_materials, cpa_id):
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(INSERT_CLIENT, (client_id, name, address, income, tax_materials, cpa_id))


# Create tax data with insert
def create_tax(connection, tax_id, Status, time, cpa_check, client_id, ):
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(INSERT_TAX_RETURN, (tax_id, Status, time, cpa_check, client_id))


# Create Assistant data with insert
def create_assistant(connection, a_id, name):
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(INSERT_ASSISTANT, (a_id, name))


# Create Cpa data with insert
def create_cpa(connection, cpa_id, Company_title, filed, a_id):
    with connection:
        with connection.cursor() as cursor:
            cursor.execute(INSERT_CPA, (cpa_id, Company_title, filed, a_id,))


# Getting data from clients
def get_clients(connection):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_ALL_CLIENT)
        return cursor.fetchall()


# Getting data from cpa
def get_cpa(connection):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_ALL_CPA)
        return cursor.fetchall()


# Geting data from assistants
def get_assistants(connection):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_ALL_ASSISTANT)
        return cursor.fetchall()


# Geting data from tax
def get_tax(connection):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_ALL_TAX_RETURNS)
        return cursor.fetchall()


# Geting data from assistants with assistant id
def get_assistant(connection, a_id):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_ASSISTANT, (a_id,))
        return cursor.fetchone()


# Geting data from cpa by cpa id
def get_single_cpa(connection, cpa_id):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_SINGLE_CPAA, (cpa_id,))
        return cursor.fetchone()


# Geting data from clients by client id
def get_single_client(connection, client_id):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_CLIENT, (client_id,))
        return cursor.fetchone()


# Getting data from tax by tax id
def get_single_tax(connection, tax_id):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_TAX, (tax_id,))
        return cursor.fetchone()


# Seeing if cpa id exist
def item_exists(connection, cpa_id):
    with connection.cursor() as cursor:
        cursor.execute(CHECK_IF_ITEM_NAME_EXISTS, (cpa_id,))
        if cursor.fetchone() is None:
            return False  # error handling
        else:
            return True


# Seeing if assistnat id exist
def item_exists_assistant(connection, a_id):  # another checking if item exist
    with connection.cursor() as cursor:
        cursor.execute(CHECK_IF_ASSISTANT_EXIST, (a_id,))
        if cursor.fetchone() is None:
            return False
        else:
            return True


# Seeing if client id exist
def item_exists_client(connection, tax_id):  # another checking if item exist
    with connection.cursor() as cursor:
        cursor.execute(CHECK_IF_TAX_EXISTS, (tax_id,))
        if cursor.fetchone() is None:
            return False
        else:
            return True


# updating Filed maker in cpa for if assistant filed it
def update_cpa(connection, filed, cpa_id):
    with connection.cursor() as cursor:
        cursor.execute(UPDATE_CPA, (filed, cpa_id,))


# updating assistant name just for practice
def update_assistant(connection, filed, a_id):
    with connection.cursor() as cursor:
        cursor.execute(UPDATE_ASSISTANT, (filed, a_id,))


# update client marker manually if person wants to chang it
def update_client(connection, tax_materials, client_id):
    with connection.cursor() as cursor:
        cursor.execute(UPDATE_CLIENT, (tax_materials, client_id,))


# update tax status in tax manually
def update_tax(connection, cpa_check, tax_id):
    with connection.cursor() as cursor:
        cursor.execute(UPDATE_TAX, (cpa_check, tax_id,))


# using this for my compare method in tax return to turn cpa check the opposite of the assistant filing marker
def get_single_cpaa(connection, cpa_id):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_SINGLE_CPAA, (cpa_id,))
        return cursor.fetchone()
