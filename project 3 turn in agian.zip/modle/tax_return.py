import database
from connection import get_connection


class Tax_return:
    def __init__(self, tax_id, Status, time, cpa_check, client_id):
        self.tax_id = tax_id
        self.Status = Status
        self.time = time
        self.cpa_check = cpa_check
        self.client_id = client_id

    # printing data from geter methods/ is my checker's checker lol
    def __repr__(self):
        # this is a special method used to represent a class’s objects as a string
        return f"Tax id: {self.tax_id} | Filling Status: {self.Status} | Time of filling: {self.time} | Cpa Check: {self.cpa_check} | Client Id: {self.client_id}"

    def save(self):  # tax.save()
        connection = get_connection()
        new_poll_id = database.create_tax(connection, self.tax_id, self.Status, self.time, self.cpa_check,
                                          self.client_id)  # saving data from user into class
        connection.close()
        self.tax_id = new_poll_id

    @classmethod  # all data graber
    def get_tax_return_info(cls):
        connection = get_connection()
        with connection:
            client_data = database.get_tax(connection)
        if client_data:
            return [cls(*data) for data in client_data]  # unpacking all data
        else:
            return None  # error handling

    @classmethod  # Fetching all data for tax view / checker
    def get_tax_return_single_info(cls, try_id):  # Fetching single data for tax view / checker
        connection = get_connection()
        with connection:
            client_data = database.get_single_tax(connection, try_id)  # get single data set in tax by id
        if client_data:
            return cls(*client_data)  # unpack the single data
        else:
            return None  # error handling

    @classmethod
    def update(cls, tax_id, cpa_check):  # Update the marker manually if user needs to fix a mistake
        connection = get_connection()
        with connection:
            if database.item_exists_client(connection, tax_id):  # checking if it exist
                database.update_tax(connection, cpa_check, tax_id)  # updating the data with new set of data
        connection.close()
        return cls
