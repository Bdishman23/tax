import database
from connection import get_connection


# initialize Assistant class
class Assistant:
    def __init__(self, a_id, name):
        self.a_id = a_id
        self.name = name

    # used to print in client magic
    def __repr__(self):
        return f"Assistant Id: {self.a_id} | Name: {self.name}"

    # Saving data from Assistant magic
    def save(self):  # assistant.save()
        connection = get_connection()
        new_a_id = database.create_assistant(connection, self.a_id, self.name)  # saving data in class
        connection.close()
        self.a_id = new_a_id

    @classmethod  # Fetching all data for assistants view / checker
    def get_assistant_info(cls):
        connection = get_connection()
        with connection:
            client_data = database.get_assistants(connection)  # getting all data in assistant
        if client_data:
            return [cls(*data) for data in client_data]  # unpacking all the data in the client_variable
        else:
            return None  # if no data return nothing

    @classmethod  # Fetching single data for assistants view / checker
    def get_assistant_single_info(cls, try_id):
        connection = get_connection()
        with connection:
            client_data = database.get_assistant(connection, try_id)  # get single data set in assistant by id
        if client_data:
            return cls(*client_data)  # unpack the single data
        else:
            return None  # error handling

    @classmethod
    def update(cls, a_id, filed):  # Update the marker manually if assistant or user needs to fix a mistake
        connection = get_connection()
        with connection:
            if database.item_exists_assistant(connection, a_id):  # checking if data exist
                database.update_assistant(connection, filed, a_id)  # updating the data with new set of data
        connection.close()
        return cls
