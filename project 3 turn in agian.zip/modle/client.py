from connection import get_connection
import database


class Client:

    def __init__(self, client_id, name, address, income, tax_materials, cpa_id):
        self.id = client_id
        self.name = name
        self.address = address
        self.income = income
        self.tax_materials = tax_materials
        self.cpa_id = cpa_id

    def __str__(self):
        return (f"Client id: {self.id} | Name: {self.name} | Address: {self.address}  | Income: ${self.income} | Tax "
                f"Materials: {self.tax_materials} | Cpa Id: {self.cpa_id}")

    def save(self):  # client.save()
        connection = get_connection()
        new_id = database.create_client(connection, self.id, self.name, self.address, self.income,
                                        self.tax_materials, self.cpa_id)  # saving data in the class
        connection.close()
        self.id = new_id

    @classmethod
    def get_client_info(cls):
        connection = get_connection()
        with connection:
            client_data = database.get_clients(connection)
        if client_data:
            return [cls(*data) for data in client_data]
        else:
            return None

    @classmethod  # Fetching all data for client view / checker
    def get_client_single_info(cls, try_id):  # Fetching single data for client view / checker
        connection = get_connection()
        with connection:
            client_data = database.get_single_client(connection, try_id)  # get single data set in client by id
        if client_data:
            return cls(*client_data)  # unpack the single data
        else:
            return None  # error handling

    @classmethod
    def update(cls, client_id, filed):  # Update the marker manually if client or user needs to fix a mistake
        connection = get_connection()
        with connection:
            database.update_client(connection, filed, client_id)  # updating the data with new set of data
        connection.close()
        return cls
