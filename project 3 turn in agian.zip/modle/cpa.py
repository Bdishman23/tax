import database
from connection import get_connection

# all client info exchange
class Cpa:
    def __init__(self, cpa_id, Company_title, filed, a_id):
        self.cpa_id = cpa_id
        self.Company_title = Company_title
        self.filed = filed
        self.a_id = a_id

    def __repr__(self):
        return (f"Cpa id: {self.cpa_id} | Company Name: {self.Company_title} | Filing status: {self.filed} | Assistant "
                f"Id: {self.a_id}")

    def save(self):  # cpa.save()
        connection = get_connection()
        new_poll_id = database.create_cpa(connection, self.cpa_id, self.Company_title, self.filed, self.a_id)
        # saving into class
        connection.close()
        self.cpa_id = new_poll_id

    @classmethod
    def get_cpa_info(cls):
        connection = get_connection()
        with connection:
            client_data = database.get_cpa(connection)
        if client_data:
            return [cls(*data) for data in client_data]  # unpacking all the data received
        else:
            return None

    @classmethod  # Fetching all data for cpa view / checker
    def get_cpa_single_info(cls, try_id):  # Fetching single data for cpa view / checker
        connection = get_connection()
        with connection:
            client_data = database.get_single_cpa(connection, try_id)  # get single data set in cpa by id
        if client_data:
            return cls(*client_data)  # unpack the single data
        else:
            return None  # error handling

    @classmethod
    def update(cls, cpa_id, filed):  # Update the marker manually if cpa or user needs to fix a mistake
        connection = get_connection()
        with connection:
            if database.item_exists(connection, cpa_id):  # checking if data exist
                database.update_cpa(connection, filed, cpa_id)  # updating the data with new set of data
        connection.close()
        return cls

    @classmethod
    def get_cpa_single_info2(cls, try_id):  # Update the marker manually if cpa or user needs to fix a mistake
        connection = get_connection()
        with connection:
            client_data = database.get_single_cpaa(connection, try_id)
        return cls, *client_data
