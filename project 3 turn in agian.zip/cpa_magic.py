from modle.cpa import Cpa

# initialize menu
cpa_menu = '''\nPlease select one of the following options:
1. Add Cpa Information.
2. Check all Cpa.
3. Check Cpa single Information.
4. Update Assistant Marker on Status.
5. Return to Main Menu
Your selection: '''


def _print_cpa(cpa):
    print(cpa)  # print for my checkers


def prompt_add_info():  # update maker
    filed = input("New Assistant filling Status: ")
    cpa_id = input("Returning Cpa ID: ")
    try:
        return filed, cpa_id
    except:
        print("Try again")
    return "Failed"


def update_cpa():
    yo, no = prompt_add_info()  # get new info with and place it with id
    Cpa.update(no, yo)  # update maker manually


def single_cpa():  # single cpa data by id
    old_id = input("What Cpa ID are you looking for?: ")
    clients = Cpa.get_cpa_single_info(old_id)  # pass to checker to see if the data exist by id
    if clients is not None:
        return _print_cpa(clients)  # lets print yo
    else:
        return "No clients available"  # error handle yo


def list_all_cpa():
    clients = Cpa.get_cpa_info()  # get all data from cpa table
    if clients is not None:
        for client in clients:
            _print_cpa(client)  # lets print all data
    else:
        return "No Cpa Available"  # error handle


def create_cpa():
    cpa_id = input("Enter Cpa Id: ")
    Company_title = input("Company Name: ")
    filed = input("Did the Assistant file it: ")
    a_id = input("Enter Assistant Id: ")
    bert = Cpa(cpa_id, Company_title, filed, a_id)
    Cpa.save(bert)


def cpa_menu_options():
    while (options := input(cpa_menu)) != '5':
        if options == '1':
            create_cpa()
        elif options == '2':
            list_all_cpa()
        elif options == '3':
            single_cpa()
        elif options == '4':
            update_cpa()
        else:
            print('Returning back to main menu.')
